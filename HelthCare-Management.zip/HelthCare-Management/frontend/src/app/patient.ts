export class Patient {

    patientid!:number;
    patientfirstname!:string;
    patientlastname!:string;
    patientemail!:string;
    patientmobile!:number;
    patientpassword!:string;


}

export class Nurse {

    nurseid!:number;
    nursefirstname!:string;
    nurselastname!:string;
    nurseemail!:string;
    nursemobile!:number;
    nursepassword!:string;

}

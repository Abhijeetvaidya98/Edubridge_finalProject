import { Component } from '@angular/core';

@Component({
  selector: 'app-user-about-us',
  templateUrl: './user-about-us.component.html',
  styleUrls: ['./user-about-us.component.css']
})
export class UserAboutUsComponent {

}
